# 👋 Olá, eu sou Gabriel Pessatto Soprani

Sou estudante de **TSI** e apaixonado por desenvolvimento web, IA e sistemas.

## 🚀 Tecnologias
- HTML, CSS, JavaScript  
- Python  
- Git & GitHub  

## 📌 Projetos
- Em breve adicionarei novos repositórios!

## 📫 Contato
- Email: seu.email@exemplo.com

---
✨ *README otimizado para GitHub Profile — sem CSS externo, 100% compatível com Markdown.*