# 🌐 Perfil Completo — README + GitHub Pages

Este pacote inclui:
- `README.md` estilizado para o GitHub
- `index.html` com `styles.css` para GitHub Pages
- Imagem de perfil

## 🎯 Sobre mim
Sou estudante de TSI e desenvolvo projetos web e aplicações com IA.

## 🔗 Acesse minha página
Quando subir para o GitHub Pages, ficará disponível como:

```
https://SEU_USUARIO.github.io
```
